import pandas as pd
import random

def stratified_folds_to_csv(csv_path, output_csv_path):
    df = pd.read_csv(csv_path)

    class_column = df.columns[-1]
    class_values = df[class_column].unique()

    random.seed(42)

    class_groups = {label: df[df[class_column] == label].sample(frac=1, random_state=42).reset_index(drop=True)
                    for label in class_values}

    folds = [[] for _ in range(10)]

    for label, rows in class_groups.items():
        for i, row in rows.iterrows():
            fold_index = i % 10
            folds[fold_index].append(row)

    output_rows = []

    for i, fold_rows in enumerate(folds, start=1):
        output_rows.append([f"fold{i}"] + [""] * (df.shape[1] - 1))

        fold_df = pd.DataFrame(fold_rows, columns=df.columns)
        output_rows.extend(fold_df.values.tolist())

        output_rows.append([""] * df.shape[1])

    output_df = pd.DataFrame(output_rows, columns = [f"fold1"] + [""] * (df.shape[1] - 1))
    output_df = output_df.tail(-1)
    output_df.to_csv(output_csv_path, index=False)

stratified_folds_to_csv("occupancy.csv", "occupancy-folds.csv")
