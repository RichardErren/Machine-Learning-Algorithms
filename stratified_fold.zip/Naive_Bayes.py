import time
import math
import csv

def training_test_split(FoldFile, TrainingFile, TestFile, fold : int):
    try:
        filename = TrainingFile
        f = open(filename, "w+")
        f.close()
        filename = TestFile
        f = open(filename, "w+")
        f.close()
        with open(FoldFile, "r") as csvfile:
            reader_variable = csv.reader(csvfile, delimiter=",")
            for row in reader_variable:
                if row[0].startswith("fold"):
                    if row[0] == f"fold{fold}":
                        f = TestFile
                        continue
                    else:
                        f = TrainingFile
                        continue
                if row[0] == "":
                    continue
                append_file = open(f,'a')
                writer = csv.writer(append_file)
                writer.writerow(row)
                append_file.close()
    except FileNotFoundError:
        print("File is not found")
        return

def gaussian_logpdf(x, mean, var):
    if var == 0:
        var = 1e-6
    return -0.5 * math.log(2 * math.pi * var) - ((x - mean) ** 2) / (2 * var)

def classify_nb(training_file, testing_file):
    with open(training_file, 'r') as file:
        training_data = list(csv.reader(file))
        
    data_yes = []
    data_no = []
    for row in training_data:
        features = list(map(float, row[:-1]))
        class_value = row[-1]
        if class_value == "yes":
            data_yes.append(features)
        else:
            data_no.append(features)

    prior_yes = len(data_yes) / len(training_data)
    prior_no = len(data_no) / len(training_data)

    num_attributes = len(training_data[0]) - 1


    def mean(values):
        if not values:
            return 0
        return sum(values) / len(values)

    def variance(values, mean_value):
        if not values:
            return 0
        return sum((x - mean_value) ** 2 for x in values) / len(values)

    params_yes = []
    params_no = []

    for i in range(num_attributes):
        values_yes = [example[i] for example in data_yes]
        values_no = [example[i] for example in data_no]
        
        m_yes = mean(values_yes)
        m_no  = mean(values_no)
        
        var_yes = variance(values_yes, m_yes)
        var_no  = variance(values_no, m_no)
        
        if var_yes == 0:
            var_yes = 1e-6
        if var_no == 0:
            var_no = 1e-6
        
        params_yes.append((m_yes, var_yes))
        params_no.append((m_no, var_no))

    with open(testing_file, 'r') as file:
        testing_data = list(csv.reader(file))

    predictions = []
    for row in testing_data:
        test_features = list(map(float, row[:-1]))
        
        log_prob_yes = math.log(prior_yes) if prior_yes > 0 else float("-inf")
        log_prob_no  = math.log(prior_no) if prior_no > 0 else float("-inf")
        
        for i, x in enumerate(test_features):
            m_yes, var_yes = params_yes[i]
            m_no, var_no   = params_no[i]
            log_prob_yes += gaussian_logpdf(x, m_yes, var_yes)
            log_prob_no  += gaussian_logpdf(x, m_no, var_no)
        
        if log_prob_yes >= log_prob_no:
            predictions.append("yes")
        else:
            predictions.append("no")
    
    return predictions

def main():
    accuracy_ls = []
    for i in range(1, 11):
        training_test_split("pima-folds.csv", "training.csv", "test.csv", i)
        with open("test.csv","r") as f:
            actual = []
            reader_variable = csv.reader(f, delimiter=",")
            for row in reader_variable:
                actual.append(row[-1])
        results = classify_nb("training.csv", "test.csv")
        count = 0
        for i in range(len(results)):
            if results[i] == actual[i]:
                count += 1
        accuracy = (count/len(results))
        accuracy_ls.append(accuracy)
    total = 0
    for acc in accuracy_ls:
        total += acc
    avg_accuracy = total/len(accuracy_ls)
    print("Average Accuracy for Naive Bayes:", round(avg_accuracy,4))


if __name__ == "__main__":
    start_time = time.time()
    main()
    print(f"Running Time: {round((time.time() - start_time),3)} seconds")
