import time
import math
import csv

def training_test_split(FoldFile, TrainingFile, TestFile, fold : int):
    try:
        filename = TrainingFile
        f = open(filename, "w+")
        f.close()
        filename = TestFile
        f = open(filename, "w+")
        f.close()
        with open(FoldFile, "r") as csvfile:
            reader_variable = csv.reader(csvfile, delimiter=",")
            for row in reader_variable:
                if row[0].startswith("fold"):
                    if row[0] == f"fold{fold}":
                        f = TestFile
                        continue
                    else:
                        f = TrainingFile
                        continue
                if row[0] == "":
                    continue
                append_file = open(f,'a')
                writer = csv.writer(append_file)
                writer.writerow(row)
                append_file.close()
    except FileNotFoundError:
        print("File is not found")
        return

def euclidean_distance(point1, point2):
    return math.sqrt(sum((float(a) - float(b)) ** 2 for a, b in zip(point1, point2)))

def classify_nn(training_file, testing_file, k):
    with open(training_file, 'r') as file:
        training_data = list(csv.reader(file))
    with open(testing_file, 'r') as file:
        testing_data = list(csv.reader(file))
    
    predictions = []

    for test_row in testing_data:
        distances = []
        for train_row in training_data:
            train_attributes = train_row[:-1]
            class_value = train_row[-1]
            dist = euclidean_distance(test_row, train_attributes)
            distances.append((dist, class_value))

        distances.sort(key=lambda x: x[0])
        nearest_classValues = []
        for i in range(k):
            dist, class_value = distances[i]
            nearest_classValues.append(class_value)

        yes_count = 0
        no_count = 0
        for class_value in nearest_classValues:
            if class_value == "yes":
                yes_count += 1
            else:
                no_count += 1

        if yes_count >= no_count:
            predictions.append("yes")
        else:
            predictions.append("no")
    
    return predictions

def main():
    accuracy_ls = []
    for i in range(1, 11):
        training_test_split("pima-folds.csv", "training.csv", "test.csv", i)
        with open("test.csv","r") as f:
            actual = []
            reader_variable = csv.reader(f, delimiter=",")
            for row in reader_variable:
                actual.append(row[-1])
        results = classify_nn("training.csv", "test.csv", 1)
        count = 0
        for i in range(len(results)):
            if results[i] == actual[i]:
                count += 1
        accuracy = (count/len(results))
        accuracy_ls.append(accuracy)
    total = 0
    for acc in accuracy_ls:
        total += acc
    avg_accuracy = total/len(accuracy_ls)
    print("Average Accuracy for KNN:", round(avg_accuracy,4))















if __name__ == "__main__":
    start_time = time.time()
    main()
    print(f"Running Time: {round((time.time() - start_time),3)} seconds")
